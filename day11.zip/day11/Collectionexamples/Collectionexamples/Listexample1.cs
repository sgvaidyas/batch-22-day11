﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collectionexamples
{
    class Listexample1
    {
        static void Main(string[] args)
        {
            var numbers = new List<int>();

            numbers.Add(11);
            numbers.Add(22);
            numbers.Add(33);
            numbers.Add(44);
            numbers.Add(33);
            numbers.Add(155);

            foreach(int i in numbers)
                Console.WriteLine(i);

            Console.WriteLine();
            List<string> names = new List<string>();
            names.Add("Karthik");
            names.Add("Manjunath");
            names.Add("Shweta");

            foreach (string n in names)
                Console.WriteLine(n);
            Console.WriteLine();

            var obj = new List<int>() { 22, 33, 77, 88 };
            foreach (int i in obj)
                Console.WriteLine(i);

            
            int ch;
            var emp = new List<EmployeeEx1>();
            do
            {
                EmployeeEx1 ob = new EmployeeEx1();
                emp.Add(ob);
                Console.WriteLine("do you want to add another record => Press 1 ");
                ch = int.Parse(Console.ReadLine());
            } while ( ch==1  );

            Console.WriteLine("\nRECORDS =\n");
            foreach (EmployeeEx1 e in emp)
                e.display();
        }
    }
}
