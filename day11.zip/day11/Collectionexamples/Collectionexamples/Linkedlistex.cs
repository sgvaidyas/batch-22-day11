﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collectionexamples
{
    class Linkedlistex
    {
        static void Main(string[] args)
        {
            var cities = new LinkedList<string>();

            cities.AddFirst("Bangalore");
            cities.AddLast("Panaji");
            cities.AddLast("Kolkatta");
            cities.AddLast("Kolkatta");

            foreach (var c in cities)
                Console.WriteLine(c);
            Console.WriteLine();
            LinkedListNode<string> nd = cities.Find("Kolkatta");

            cities.AddBefore(nd, "Chennai");

            foreach(var c in cities)
                Console.WriteLine(c);
        }
    }
}
