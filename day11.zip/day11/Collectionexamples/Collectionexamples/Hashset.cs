﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collectionexamples
{
    class Hashset
    {
        static void Main(string[] args)
        {
            var ob = new HashSet<string>();

            ob.Add("11");
            ob.Add(null);
            ob.Add("shilpa");
            ob.Add("11");

            foreach(var o in ob)
                Console.WriteLine(o);
            Console.WriteLine("\nnew hash set\n");

            var ob2 = new HashSet<int>() { 11, 22, 11, 44, 55, 44, 77 };

            foreach (var o in ob2)
                Console.WriteLine(o);
        }
    }
}
