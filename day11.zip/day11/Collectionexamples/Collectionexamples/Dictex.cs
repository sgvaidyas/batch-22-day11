﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collectionexamples
{
    class Dictex
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> ob = new Dictionary<int, string>();

            ob.Add(11, "Ashita");
            ob.Add(33, "Ashita");
            ob.Add(22, "Shreya");
            ob.Add(44, "Shravani");
            ob.Add(55, "Suja");

            foreach(KeyValuePair<int,string> kv in ob)
                Console.WriteLine(kv.Key +" : " + kv.Value);


            Console.WriteLine();
            Console.WriteLine();
            SortedDictionary<int, string> ob1 = new SortedDictionary<int, string>();

            ob1.Add(11, "Ashita");
            ob1.Add(33, "Ashita");
            ob1.Add(2, "Zaiba");
            ob1.Add(77, "Trivani");
            ob1.Add(55, "Suja");

            foreach (KeyValuePair<int, string> kv in ob1)
                Console.WriteLine(kv.Key + " : " + kv.Value);

            Console.WriteLine();
            Console.WriteLine("BY VALUES ");

            foreach (KeyValuePair<int, string> kv in ob1.OrderBy(key=>key.Value))
                Console.WriteLine(kv.Key + " : " + kv.Value);




        }
    }
}
