﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collectionexamples
{
    class Stacksex
    {
        static void Main(string[] args)
        {
            Stack<int> ob = new Stack<int>();

            ob.Push(11);
            ob.Push(22);
            ob.Push(44);

            foreach(int i in ob)
                Console.WriteLine(i);

            Console.WriteLine("Peek elemt = "+ob.Peek());
            Console.WriteLine("Popped element = " + ob.Pop());

            foreach (int i in ob)
                Console.WriteLine(i);

            Console.WriteLine("Peek elemt = " + ob.Peek());
        }
    }
}
