﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collectionexamples
{
    class Sorted
    {
        static void Main(string[] args)
        {
            SortedSet<int> ob = new SortedSet<int>() { 11, 22, 3, 4, 55, 22, 4 };

            ob.Add(66);
            ob.Add(78);

            foreach(int i in ob)
                Console.WriteLine(i);
        }
    }
}
