﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collectionexamples
{
    class Queuesex
    {
        static void Main(string[] args)
        {

            Queue<int> ob = new Queue<int>();

            ob.Enqueue(11);
            ob.Enqueue(22);
            ob.Enqueue(44);

            foreach (int i in ob)
                Console.WriteLine(i);

            Console.WriteLine("Peek elemt = " + ob.Peek());
            Console.WriteLine("Deleted element = " + ob.Dequeue());

            foreach (int i in ob)
                Console.WriteLine(i);

            Console.WriteLine("Peek elemt = " + ob.Peek());
        }
    }
}
