﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collectionexamples
{
    class EmployeeEx1
    {
        public int Id;
        public string name;
        public float sal;
        public EmployeeEx1()
        {
            Console.WriteLine("ENTER  ID NAME SAL");
            Id = int.Parse(Console.ReadLine());
            name = Console.ReadLine();
            sal = float.Parse(Console.ReadLine());
        }
        public EmployeeEx1(int x, string n, float s)
        {
            Id = x;
            name = n;
            sal = s;
        }
        public void display()
        {
            Console.WriteLine("ID  = {0}       NAME = {1}     SALARY = {2}",Id,name,sal);
        }
    }
}
