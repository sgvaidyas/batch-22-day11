﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinglyLinkedlist
{
    class NodeData
    {
        public int data;

        public NodeData nextadd;
    };
    class SingleLinked
    {
        public NodeData head;
        public int count;

        public SingleLinked()
        {
            head = null;
            count = 0;
        }
        public NodeData createnode(int ele)
        {
            NodeData temp = new NodeData();
            temp.data = ele;
            temp.nextadd = null;
            count++;
            return temp;
        }
        public void insertbegin(int ele)
        {
            NodeData newnode = createnode(ele);
            newnode.nextadd = head;
            head = newnode;
        }


        public void insertend(int ele)
        {
            NodeData newnode = createnode(ele);
            if (head == null)
                head = newnode;
            else
            {
                NodeData temp = head;
                while (temp.nextadd != null)
                    temp = temp.nextadd;

                temp.nextadd = newnode;
            }
        }
        public void insertpos(int ele, int pos)
        {
            if (pos == 1)
                insertbegin(ele);
            else if (pos == count + 1)
                insertend(ele);
            else
            {
                NodeData newnode = createnode(ele);
                NodeData pn, cn;
                pn = cn = head;
                for (int i = 1; i < pos; i++)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                pn.nextadd = newnode;
                newnode.nextadd = cn;
            }
        }
        public void deletebegin()
        {
            if (head == null)
                Console.WriteLine("No elements in the list - Deletion not possible");
            else
            {
                NodeData temp = head;
                head = head.nextadd;
                Console.WriteLine("Deleting the node with value = " + temp.data);
                temp = null;
                count--;
            }
        }

        public void deleteend()
        {
            if (head == null)
                Console.WriteLine("No elements in the list - Deletion not possible");
            else
            {
                NodeData pn, cn;
                pn = cn = head;
                while (cn.nextadd != null)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                //if only 1 node is esisting after deletion head should point to null
                if (pn == cn)
                    head = null;

                pn.nextadd = null;

                Console.WriteLine("Deleting the node with value = " + cn.data);
                cn = null;
                count--;
            }
        }

        public void deletepos(int pos)
        {
            if (pos == 1)
                deletebegin();
            else if (pos == count)
                deleteend();
            else
            {
                NodeData pn, cn;
                pn = cn = head;

                for (int i = 1; i < pos; i++)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                pn.nextadd = cn.nextadd;
                Console.WriteLine("Deleting the node with value = " + cn.data);
                cn = null;
                count--;
            }

        }


        public void display()
        {
            if (head == null)
                Console.WriteLine("No elements in the list");
            else
            {
                Console.WriteLine("\nElements of list are :");
                NodeData temp;
                temp = head;
                while (temp != null)
                {
                    Console.Write(temp.data + "  \t");
                    temp = temp.nextadd;
                }
                Console.WriteLine();
            }
        }
    }
}
