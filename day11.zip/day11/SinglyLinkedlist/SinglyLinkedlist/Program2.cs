﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinglyLinkedlist
{
    class Program2
    {
        static void Main(string[] args)
        {

            Single ob = new Single();
            int ch, pos;

            do
            {
                Console.WriteLine("1 Insert in the beginning");
                Console.WriteLine("2 Insert in the end");
                Console.WriteLine("3 Insert at  a given pos");
                Console.WriteLine("4 Delete at the beginning");
                Console.WriteLine("5 Delete at the end");
                Console.WriteLine("6 Delete at  a given pos");
                Console.WriteLine("7 Display");
                Console.WriteLine("8 Exit");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1: ob.insertbegin();break;
                    case 2:ob.insertend(); break;
                    case 3:
                        do
                        {
                            Console.WriteLine("Enter position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos<1 ||  pos> ob.count+1);

                        ob.insertpos(pos);
                        break;
                    case 4:ob.deletebegin();break;
                    case 5: ob.deleteend(); break;
                    case 6:
                        do
                        {
                            Console.WriteLine("Enter position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos< 1 || pos> ob.count );
                        ob.deletepos(pos);
                        break;
                    case 7: ob.display();
                        break;
                    case 8: break;
                    default: Console.WriteLine("invalid choice"); break;
                }
            } while (ch!=8);

        }
    }
}
