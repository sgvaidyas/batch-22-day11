﻿using System;

namespace SinglyLinkedlist
{
    class Node
    {
        
        public int data;
        //added
        public string name,phone;

        public Node nextadd;
        //added
        public Node()
        {
            Console.WriteLine("Enter the roll num ");
            data = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name   ");
            name = Console.ReadLine();
            Console.WriteLine("Enter the phone num ");
            phone= Console.ReadLine();
            nextadd = null;
        }
        public void display()
        {
            Console.WriteLine("RECORD...............");
            Console.WriteLine("ROLL NO           "+data);
            Console.WriteLine("NAME              " + name);
            Console.WriteLine("PHONE NO          " + phone);

        }
    };
    class Single
    {
        public Node head;
        public int count;

        public Single()
        {
            head = null;
            count = 0;
        }
        public Node createnode()
        {
            Node temp = new Node();
            count++;
            return temp;
        }
        public void insertbegin()
        {
            Node newnode = createnode();
            newnode.nextadd = head;
            head = newnode;
        }
        public void insertend()
        {
            Node newnode =  createnode() ;
            if (head == null)
                head = newnode;
            else
            {
                Node temp = head;
                while (temp.nextadd != null)
                    temp = temp.nextadd;

                temp.nextadd = newnode;
            }
        }
        public void insertpos(int pos)
        {
            if (pos == 1)
                insertbegin();
            else if (pos == count + 1)
                insertend();
            else
            {
                Node newnode = createnode();
                Node pn, cn;
                pn = cn = head;
                for(int i=1;i<pos;i++)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                pn.nextadd = newnode;
                newnode.nextadd = cn;
            }
        }
        public void deletebegin()
        {
            if(head==null)
                Console.WriteLine("No elements in the list - Deletion not possible");
            else
            {
                Node temp = head;
                head = head.nextadd;
                Console.WriteLine("Deleting the node " );
                temp.display();
                temp = null;
                count--;
            }
        }

        public void deleteend()
        {
            if (head == null)
                Console.WriteLine("No elements in the list - Deletion not possible");
            else
            {
                Node pn, cn;
                pn = cn = head;
                while(cn.nextadd!=null)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                //if only 1 node is esisting after deletion head should point to null
                if (pn == cn)
                    head = null;

                pn.nextadd = null;

                Console.WriteLine("Deleting the node " );
                cn.display();
                cn = null;
                count--;
            }
        }

        public  void deletepos(int pos)
        {
            if (pos == 1)
                deletebegin();
            else if (pos == count)
                deleteend();
            else
            {
                Node pn, cn;
                pn = cn = head;

                for(int i=1;i<pos;i++)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                pn.nextadd = cn.nextadd;
                Console.WriteLine("Deleting the node ");
                cn.display();
                cn = null;
                count--;
            }

        }


        public void display()
        {
            if(head==null)
                Console.WriteLine("No elements in the list");
            else
            {
                Console.WriteLine("\nElements of list are :");
                Node temp;
                temp = head;
                while(temp!=null)
                {
                    Console.Write("_________________________________");
                    temp.display();
                    temp = temp.nextadd;
                }
                Console.WriteLine();
            }
        }
    }
}
