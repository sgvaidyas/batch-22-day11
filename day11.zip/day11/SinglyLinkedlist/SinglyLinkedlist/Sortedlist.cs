﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinglyLinkedlist
{
    
    class Sortedlist
    {
        public Node head;
        public int count;

        public Sortedlist()
        {
            head = null;
            count = 0;
        }
        public Node createnode(int ele)
        {
            Node temp = new Node();
            temp.data = ele;
            temp.nextadd = null;
            count++;
            return temp;
        }
        public void insertsort(int ele)
        {
            Node newnode = createnode(ele);
            if (head == null)
                head = newnode;
            else
            {
                Node pn,cn;
                pn= head;
                cn = head;

                while(cn != null && cn.data<ele)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }

                if(pn==cn)
                {
                    newnode.nextadd = head;
                    head = newnode;
                }
                else
                {
                    pn.nextadd = newnode;
                    newnode.nextadd = cn;
                }
            }
        }
        public void display()
        {
            if (head == null)
                Console.WriteLine("No elements in the list");
            else
            {
                Console.WriteLine("\nElements of list are :");
                Node temp;
                temp = head;
                while (temp != null)
                {
                    Console.Write(temp.data + "  \t");
                    temp = temp.nextadd;
                }
                Console.WriteLine();
            }
        }
        static void Main(string[] args)
        {
            Sortedlist ob = new Sortedlist();
            ob.insertsort(22);
            ob.display();
            ob.insertsort(33);
            ob.display();
            ob.insertsort(11);
            ob.insertsort(22);
            ob.display();
        }
    }
}
